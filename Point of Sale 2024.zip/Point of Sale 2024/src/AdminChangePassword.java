
import java.awt.Color;
import javax.swing.JOptionPane;

public class AdminChangePassword extends javax.swing.JFrame {

    public AdminChangePassword() {
        initComponents();
        setSize(600, 400);
        setTitle("Change Password");
        getContentPane().setBackground(Color.DARK_GRAY);
        setLocationRelativeTo(null);    // to put jframe in centre
        setVisible(true);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jf1 = new javax.swing.JPasswordField();
        jf2 = new javax.swing.JPasswordField();
        jf3 = new javax.swing.JPasswordField();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("CHANGE PASSWORD");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(170, 40, 240, 40);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Old Password :");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(130, 110, 110, 30);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("New Password :");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(130, 170, 100, 20);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Confirm Password :");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(120, 230, 130, 20);

        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton1.setText("CHANGE");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(360, 290, 90, 40);
        getContentPane().add(jf1);
        jf1.setBounds(290, 110, 160, 30);

        jf2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jf2ActionPerformed(evt);
            }
        });
        getContentPane().add(jf2);
        jf2.setBounds(290, 170, 160, 30);
        getContentPane().add(jf3);
        jf3.setBounds(290, 230, 160, 30);

        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton2.setText("BACK");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(20, 20, 90, 40);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jf2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jf2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jf2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        String oldpassword = jf1.getText();
        String newpassword = jf2.getText();
        String confirmpassword = jf3.getText();

        if (oldpassword.equals("") || newpassword.equals("") || confirmpassword.equals("")) {
            JOptionPane.showMessageDialog(this, "All Fields Required");
        } else {
            if (newpassword.equalsIgnoreCase(confirmpassword)) {
                String ans = MyClient.changePass(oldpassword, newpassword);
                if (ans.equals("success")) {
                    JOptionPane.showMessageDialog(this, "Password changed successfully");
                    dispose();  // to close the current window after password change
                    AdminLogin obj = new AdminLogin();  // to relogin with new password
                } else {
                    JOptionPane.showMessageDialog(this, "Incorrect old password");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Password doesn't match");
            }

        }


    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        dispose();
        AdminHome obj = new AdminHome();
    }//GEN-LAST:event_jButton2ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdminChangePassword.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdminChangePassword.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdminChangePassword.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdminChangePassword.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminChangePassword().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPasswordField jf1;
    private javax.swing.JPasswordField jf2;
    private javax.swing.JPasswordField jf3;
    // End of variables declaration//GEN-END:variables
}
