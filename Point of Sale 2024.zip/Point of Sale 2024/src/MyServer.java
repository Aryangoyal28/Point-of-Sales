
import com.vmm.JHTTPServer;
import java.io.IOException;
import java.util.Properties;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MyServer extends JHTTPServer {

    @Override
    public Response serve(String uri, String method, Properties header, Properties parms, Properties files) {

        if (uri.equals("/adminlogin")) {
            String ans = "";
            String email = parms.getProperty("em");
            String password = parms.getProperty("pass");
            ResultSet rs = DBLoader.executeSql("select * from admin where email = '" + email + "' and password = '" + password + "' ");
            try {
                if (rs.next()) {
                    Global.email = email;    // isse sirf jis id se log in kiya hai usi ka password change hoega
                    ans = "success";
                } else {
                    ans = "fail";
                }
            } catch (SQLException ex) {
                Logger.getLogger(MyServer.class.getName()).log(Level.SEVERE, null, ex);
            }
            Response res = new Response(HTTP_OK, "text/plain", ans);
            return res;
        } else if (uri.equals("/adminaddcategories")) {
            String ans = "";

            String name = parms.getProperty("nm");
            String desc = parms.getProperty("desc");

            ResultSet rs = DBLoader.executeSql("  select * from categories where catname ='" + name + "' ");
            try {
                if (rs.next()) {
                    ans = "Item Already Present";
                } else {

                    String photoname = saveFileOnServerWithRandomName(files, parms, "photo", "src/myuploads/");   // to save photo in myuploads folder

                    rs.moveToInsertRow();
                    rs.updateString("catname", name);
                    rs.updateString("desc", desc);
                    rs.updateString("photo", "src/myuploads/" + photoname);    // to save path of photo in db
                    rs.insertRow();

                    ans = "success";
                }
            } catch (SQLException e) {
                ans = e.toString();
            }
            Response res = new Response(HTTP_OK, "text/plain", ans);
            return res;
        } else if (uri.equals("/getcategoriesdata")) {
            String ans = "";
            ResultSet rs = DBLoader.executeSql("select * from categories");

            try {
                while (rs.next()) {
                    String name = rs.getString("catname");
                    String desc = rs.getString("desc");
                    String photo = rs.getString("photo");

                    String row = name + "$" + desc + "$" + photo;

                    ans = ans + row + ";;";

                }
            } catch (SQLException ex) {
                Logger.getLogger(MyServer.class.getName()).log(Level.SEVERE, null, ex);
            }

            Response res = new Response(HTTP_OK, "text/plain", ans);
            return res;
        } else if (uri.equals("/adminaddproducts")) {
            String ans = "";

            String name = parms.getProperty("nm");
            String desc = parms.getProperty("desc");
            String category = parms.getProperty("cat");
            String price = parms.getProperty("price");
            String qnty = parms.getProperty("qnty");

            ResultSet rs = DBLoader.executeSql("  select * from products where pname ='" + name + "' ");
            try {
                if (rs.next()) {
                    ans = "fail";
                } else {
                    String photoname = saveFileOnServerWithRandomName(files, parms, "photo", "src/myuploads/");

                    rs.moveToInsertRow();
                    rs.updateString("pname", name);
                    rs.updateString("desc", desc);
                    rs.updateString("catname", category);
                    rs.updateString("photo", "src/myuploads/" + photoname);    // to save path of photo in db
                    rs.updateString("price", price);
                    rs.updateString("quantity", qnty);
                    rs.insertRow();

                    ans = "success";
                }
            } catch (SQLException ex) {
                Logger.getLogger(MyServer.class.getName()).log(Level.SEVERE, null, ex);
            }
            Response res = new Response(HTTP_OK, "text/plain", ans);
            return res;
        } else if (uri.equals("/getproductsdata")) {
            String ans = "";
            ResultSet rs = DBLoader.executeSql("select * from products");

            try {
                while (rs.next()) {
                    String name = rs.getString("pname");
                    String desc = rs.getString("desc");

                    String price = rs.getString("price");
                    String photo = rs.getString("photo");

                    String row = name + "$" + desc + "$" + price + "$" + photo;

                    ans = ans + row + ";;";
                }
            } catch (SQLException ex) {
                Logger.getLogger(MyServer.class.getName()).log(Level.SEVERE, null, ex);
            }

            Response res = new Response(HTTP_OK, "text/plain", ans);
            return res;

        } else if (uri.equals("/productcombobox")) {
            ResultSet rs = DBLoader.executeSql("select catname from categories");
            String ans = "";
            try {
                while (rs.next()) {
                    String name = rs.getString("catname");
                    String row = name;
                    ans = ans + row + "$";
                }
            } catch (SQLException ex) {
                Logger.getLogger(MyServer.class.getName()).log(Level.SEVERE, null, ex);
            }

            Response res = new Response(HTTP_OK, "text/plain", ans);
            return res;
        } else if (uri.equals("/adminchangepassword")) {
            String ans = "";
            String oldp = parms.getProperty("oldpass");
            String newp = parms.getProperty("newpass");
            System.out.println(Global.email + " Loggeg In Email");
            ResultSet rs = DBLoader.executeSql("select * from admin where Email ='" + Global.email + "' and Password ='" + oldp + "' ");

            try {
                if (rs.next()) {
                    rs.updateString("Password", newp);
                    rs.updateRow();

                    ans = "success";
                } else {
                    ans = "fail";
                }
            } catch (SQLException ex) {
                Logger.getLogger(MyServer.class.getName()).log(Level.SEVERE, null, ex);
            }
            Response res = new Response(HTTP_OK, "text/plain", ans);
            return res;

        } else if (uri.equals("/showallcategories")) {
            String ans = "";
            ResultSet rs = DBLoader.executeSql("select * from categories");
            try {
                while (rs.next()) {
                    String catname = rs.getString("catname");
                    String photo = rs.getString("photo");

                    ans += catname + "," + photo + ";";
                }
            } catch (SQLException ex) {
                Logger.getLogger(MyServer.class.getName()).log(Level.SEVERE, null, ex);
            }
            Response res = new Response(HTTP_OK, "text/plain", ans);
            return res;
        } else if (uri.equals("/showallproducts")) {
            String ans = "";
            String pname = "";
            String photo = "";

            String catname = parms.getProperty("catname");

            ResultSet rs = DBLoader.executeSql("select * from products where catname='" + catname + "' ");
            try {
                while (rs.next()) {
                    pname = rs.getString("pname");
                    photo = rs.getString("photo");

                    ans += pname + "," + photo + ";";
                }
            } catch (SQLException ex) {
                Logger.getLogger(MyServer.class.getName()).log(Level.SEVERE, null, ex);
            }
            Response res = new Response(HTTP_OK, "text/plain", ans);
            return res;
        } else if (uri.equals("/checkquantity")) {
            String ans = "";

            String pname = parms.getProperty("pname");
            int quant = Integer.parseInt(parms.getProperty("quant"));

            ResultSet rs = DBLoader.executeSql("select * from products where pname = '" + pname + "' and quantity >= '" + quant + "' ");
            try {
                if (rs.next()) {
                    int currentQuantity = rs.getInt("quantity");
                    int newQuantity = currentQuantity - quant;

                    rs.updateInt("quantity", newQuantity);
                    rs.updateRow();

                    ans = "success";
                } else {
                    ans = "fail";
                }
            } catch (SQLException ex) {
                Logger.getLogger(MyServer.class.getName()).log(Level.SEVERE, null, ex);
            }
            Response res = new Response(HTTP_OK, "text/plain", ans);
            return res;

        } else if (uri.equals("/adminshowproductscart")) {
            String ans = "";
            String catname = "";
            int price = 0;
            String pname = parms.getProperty("pname");

            ResultSet rs = DBLoader.executeSql("select * from products where pname = '" + pname + "' ");
            try {
                while (rs.next()) {
                    pname = rs.getString("pname");
                    catname = rs.getString("catname");
                    price = rs.getInt("price");

                    ans += pname + "," + catname + "," + price + ";";
                }
            } catch (SQLException ex) {
                Logger.getLogger(MyServer.class.getName()).log(Level.SEVERE, null, ex);
            }
            Response res = new Response(HTTP_OK, "text/plain", ans);
            return res;

        } else if (uri.equals("/getbill")) {
            String ans = "";

            try {
                ResultSet rs = DBLoader.executeSql("select * from bill where adminemail='" + Global.email + "' ");
                while (rs.next()) {
                    int billid = rs.getInt("billid");
                    String datetime = rs.getTimestamp("datetime").toString();
                    int gtotal = rs.getInt("gtotal");
                    String phoneno = rs.getString("phoneno");
                    String paymettype = rs.getString("paymenttype");

                    ans += billid + "," + datetime + "," + gtotal + "," + phoneno + "," + paymettype + ";";

                }
            } catch (Exception e) {
                ans = e.toString();
                e.printStackTrace();
            }

            Response res = new Response(HTTP_OK, "text/plain", ans);
            return res;
        } else if (uri.equals("/getbilldetail")) {
            String ans = "";

            String billid = parms.getProperty("billid");
            //System.out.println("Bill id "+billid);
            try {
                ResultSet rs = DBLoader.executeSql("select * from billdetail where billid='" + billid + "' ");
                while (rs.next()) {
                    int billdetailid = rs.getInt("billdetailid");
                    String pname = rs.getString("pname");
                    int price = rs.getInt("price");
                    String catname = rs.getString("catname");
                    int quantity = rs.getInt("quantity");

                    ans += billdetailid + "," + billid + "," + pname + "," + price + "," + catname + "," + quantity + ";";

                }
            } catch (Exception e) {
                ans = e.toString();
                e.printStackTrace();
            }
            Response res = new Response(HTTP_OK, "text/plain", ans);
            return res;
        } else if (uri.equals("/admindeletecategory")) {
            String ans = "";
            try {
                String catname = parms.getProperty("catname");

                ResultSet rs = DBLoader.executeSql("select * from categories where catname='" + catname + "' ");
                if (rs.next()) {
                    rs.deleteRow();
                    ans = "success";
                }
            } catch (Exception e) {
                ans = e.toString();
                e.printStackTrace();
            }
            Response res = new Response(HTTP_OK, "text/plain", ans);
            return res;
        }else if (uri.equals("/admindeleteproduct")) {
            String ans = "";
            try {
                String pname = parms.getProperty("pname");

                ResultSet rs = DBLoader.executeSql("select * from products where pname='" + pname + "' ");
                if (rs.next()) {
                    rs.deleteRow();
                    ans = "success";
                }
            } catch (Exception e) {
                ans = e.toString();
                e.printStackTrace();
            }
            Response res = new Response(HTTP_OK, "text/plain", ans);
            return res;
        }

        return null;
    }

    public MyServer(int portno) throws IOException // parameterized constructor with port no. as parameter
    {                                              // isko ServerOnOff GUI mein call krna

        super(portno);                        // jis port no. pe server chlana hai

    }

}
