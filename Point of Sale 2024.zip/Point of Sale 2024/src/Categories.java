public class Categories   // Bean Class 
{
    String name;
    String desc;
    String photo;         
    
    Categories (String nm, String ds, String ph){
        name = nm;
        desc = ds;
        photo = ph;
    }
}
