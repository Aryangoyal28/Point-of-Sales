import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import java.io.File;
import java.sql.*;
import java.util.ArrayList;



public class MyClient {

    
    ArrayList<Cart> al;

    public MyClient(ArrayList<Cart> al) {
        this.al = al;
    }
    
    public static String adminLogin(String email, String password) {
        String ans = "";
        try {
            HttpResponse<String> res = Unirest.get("http://localhost:9000/adminlogin") //MyClient to MyServer request with email and password as paramters.
                    .queryString("em", email)
                    .queryString("pass", password)
                    .asString();

            ans = res.getBody();

        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }
        return ans;
    }
    
    public static String adminAddCategories(String name, String desc, File photo)   // to add data in db
    {
        String ans = "";
        try {
            HttpResponse<String> res = Unirest.post("http://localhost:9000/adminaddcategories")      // Unirest.get = for normal text fields
                    
                    .queryString("nm", name)                                                  // Unirest.post = normal tf + for uploading photo
                    .queryString("desc", desc)                                                //   (more secured as it uses hashingSSSSSSSS)
                    .field("photo",photo)
                    .asString();
            
            ans = res.getBody();
            
            
        }catch ( Exception e)
        {
            e.printStackTrace();
        }
        return ans;
    }
    
    public static String getCategoriesData()   // to get(view) data from db in table
    {
        String ans = "";
        try {
            HttpResponse<String> res = Unirest.get("http://localhost:9000/getcategoriesdata")                  
                   .asString();
            
            ans = res.getBody();
            
            
        }
         
         catch ( Exception e)
        {
            e.printStackTrace();
        }
        return ans;
       
    }
    
    public static String adminAddProducts(String name, String desc, String category, File photo, String price, String qnty)  // to add products in db
    {
        String ans = "";
        try {
            HttpResponse<String> res = Unirest.post("http://localhost:9000/adminaddproducts")
                    
                    
                    .queryString("nm", name)                                                  // Unirest.post = normal tf + for uploading photo
                    .queryString("desc", desc)
                    .queryString("cat", category)
                    .queryString("price", price)
                    .queryString("qnty", qnty)
                    .field("photo",photo)
                    
                    .asString();
            
            ans = res.getBody();
        }   
        catch ( Exception e)
        {
            e.printStackTrace();
        }
        return ans;
    }
    
    public static String getProductsData()  // to view data in table
    {
        String ans = "";
         try {
            HttpResponse<String> res = Unirest.get("http://localhost:9000/getproductsdata")                  
                   .asString();
            
            ans = res.getBody();
            
            
        }
         
         catch ( Exception e)
        {
            e.printStackTrace();
        }
        return ans;
    }
    
    public static String productComboBox()  // to view data in table
    {
        String ans = "";
         try {
            HttpResponse<String> res = Unirest.get("http://localhost:9000/productcombobox")                  
                   .asString();
            
            ans = res.getBody();
            
            
        }
         
         catch ( Exception e)
        {
            e.printStackTrace();
        }
        return ans;
    }
    
    public static String changePass(String oldp , String newp)
    {
        String ans = "" ;
        try
        {
            HttpResponse<String> res = Unirest.get("http://localhost:9000/adminchangepassword") 
                    .queryString("oldpass", oldp)
                    .queryString("newpass", newp)
                    .asString();

            ans = res.getBody();

        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }
        return ans;
    }
    
   public static String showAllCategories()
   {
       String ans = "";
       try{
            HttpResponse<String> res = Unirest.get("http://localhost:9000/showallcategories") 
                    .asString();

            ans = res.getBody();
           
       }catch (Exception e) 
        {
            e.printStackTrace();
        }
       return ans;
   }
   
   public static String showAllProducts(String catname)
   {
        String ans = "";
        try{
            HttpResponse<String> res = Unirest.get("http://localhost:9000/showallproducts") 
                    .queryString("catname", catname)  // pehla naam server pe jaaega aur doosra function ka parameter hai
                    .asString();

            ans = res.getBody();
           
       }catch (Exception e) 
        {
            e.printStackTrace();
        }
        return ans;
       
   }
   
   public static String checkQuantity(int quantity, String pname)
   {
       String ans ="";
       try{
            HttpResponse<String> res = Unirest.get("http://localhost:9000/checkquantity") 
                    .queryString("quant", quantity)
                    .queryString("pname", pname)
                    .asString();

            ans = res.getBody();
           
       }catch (Exception e) 
        {
            e.printStackTrace();
        }
       return ans;
   }
    
   
   public static String adminShowProductsCart(String pname)
   {
       String ans ="";
       try{
            HttpResponse<String> res = Unirest.get("http://localhost:9000/adminshowproductscart") 
                    .queryString("pname", pname)
                    .asString();

            ans = res.getBody();
           
       }catch (Exception e) 
        {
            e.printStackTrace();
        }
       return ans;
   }
   
   public String payment(String phoneno, String paymenttype) {
        String ans = "";
        int billid = 0;
        try {

            ResultSet rs = DBLoader.executeSql("select * from bill");
            rs.moveToInsertRow();
            rs.updateInt("gtotal", Global.gtotal);
            rs.updateString("adminemail", Global.email);
            rs.updateString("phoneno", phoneno);
            rs.updateString("paymenttype", paymenttype);
            rs.insertRow();
            
             ResultSet rs2 = DBLoader.executeSql("select MAX(billid) as billid from bill ");
            if (rs2.next()) {
                billid = rs2.getInt("billid");
            }

            for (int i = 0; i < al.size(); i++) {
                ResultSet rs3 = DBLoader.executeSql("select * from billdetail");
                rs3.moveToInsertRow();
                
                rs3.updateInt("billid", billid);
                rs3.updateString("pname", al.get(i).pname);
                rs3.updateInt("price", al.get(i).price);
                rs3.updateInt("quantity", al.get(i).quantity);
                rs3.updateString("catname", al.get(i).catname);
                
                rs3.insertRow();
            }
            
            al.clear();

            ans = "success";
        } catch (Exception e) {
            ans = e.toString();
            e.printStackTrace();
        }
        return ans;
    }
   
   public static String getBill()
   {
       String ans ="";
       try{
            HttpResponse<String> res = Unirest.get("http://localhost:9000/getbill") 
                    .asString();

            ans = res.getBody();
           
       }catch (Exception e) 
        {
            e.printStackTrace();
        }
       return ans;
   }
    
   public static String getBillDetail(int billid){
       String ans = "";
       try{
            HttpResponse<String> res = Unirest.get("http://localhost:9000/getbilldetail")
                    .queryString("billid", billid)
                    .asString();

            ans = res.getBody();
           
       }catch (Exception e) 
        {
            e.printStackTrace();
        }
       
       return ans;
   }
   
   public static String adminDeleteCategory(String catname){
       String ans = "";
        try{
            HttpResponse<String> res = Unirest.get("http://localhost:9000/admindeletecategory")
                    .queryString("catname", catname)
                    .asString();

            ans = res.getBody();
           
       }catch (Exception e) 
        {
            e.printStackTrace();
        }
       
       return ans;
       
   }
   
   public static String adminDeleteProducts(String pname){
       String ans = "";
        try{
            HttpResponse<String> res = Unirest.get("http://localhost:9000/admindeleteproduct")
                    .queryString("pname", pname)
                    .asString();

            ans = res.getBody();
           
       }catch (Exception e) 
        {
            e.printStackTrace();
        }
       
       return ans;
       
   }

}
