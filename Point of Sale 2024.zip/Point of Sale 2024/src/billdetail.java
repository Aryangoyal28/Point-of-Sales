public class billdetail {
    
    int billdetailid = 0;
    int billid = 0;
    String pname = "";
    int price = 0;
    int quantity =0;
    String catname = "";
    
    public billdetail(int billdetailid, int billid, String pname, String catname, int price,int quantity ){
        
        this.billdetailid = billdetailid;
        this.billid = billid;
        this.pname = pname;
        this.catname = catname;
        this.price = price;
        this.quantity = quantity;
        
    }
    
}
