public class Products // bean class
{
    String name;
    String desc;
    String price;
    String photo;         
    
    Products (String nm, String ds, String pr, String ph)
    {
        name = nm;
        desc = ds;
        price = pr;
        photo = ph;
    }
}
