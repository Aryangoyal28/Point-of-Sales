import java.awt.Color;
import java.util.ArrayList;
import java.util.StringTokenizer;
import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableModel;

public class BillHistory extends javax.swing.JFrame {

    ArrayList<bill> al;   // for 1st table
    TableModel tm;
    
    ArrayList<billdetail> al2;  // for 2nd table
    TableModel2 tm2;

    public BillHistory() 
    {
        initComponents();
        
        getContentPane().setBackground(Color.DARK_GRAY);
        setTitle("Bill History");
        setVisible(true);
        
        setExtendedState(MAXIMIZED_BOTH);
        
        jl2.setText(Global.email);

        al = new ArrayList<>();
        tm = new TableModel() ;
        jTable1.setModel(tm);
        
        al2 = new ArrayList<>();
        tm2 = new TableModel2();
        jTable2.setModel(tm2);
        
        showBill();
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jl2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 40)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("BILL HISTORY");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(520, 20, 270, 60);

        jl2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jl2.setForeground(new java.awt.Color(255, 255, 255));
        getContentPane().add(jl2);
        jl2.setBounds(590, 80, 300, 40);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(170, 170, 490, 340);

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        getContentPane().add(jScrollPane2);
        jScrollPane2.setBounds(680, 170, 470, 340);

        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton1.setText("GET DETAILS");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(510, 530, 150, 60);

        jButton2.setText("BACK");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(20, 20, 100, 50);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Admin :");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(520, 80, 70, 40);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        int column = 0;
        int row = jTable1.getSelectedRow();
        
        int billid = Integer.parseInt(jTable1.getValueAt(row, column).toString());
        
        String ans = MyClient.getBillDetail(billid);
        showBillDetail(ans);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        dispose();
        AdminHome obj = new AdminHome();
    }//GEN-LAST:event_jButton2ActionPerformed

    int count = 0;

    void showBill() {

        String ans = MyClient.getBill();
        

        StringTokenizer st = new StringTokenizer(ans, ";");
        count = st.countTokens();

        for (int i = 0; i < count; i++) {
            String arr = st.nextToken();
            

            StringTokenizer st2 = new StringTokenizer(arr, ",");

            int billid = Integer.parseInt(st2.nextToken());
            String datetime = st2.nextToken();
            int gtotal = Integer.parseInt(st2.nextToken());
            String phoneno = st2.nextToken();
            String paymenttype = st2.nextToken();
            
            al.add(new bill(billid, datetime, phoneno, paymenttype, gtotal));
        }
        tm.fireTableDataChanged();
    }

    public class TableModel extends AbstractTableModel {

        @Override
        public int getRowCount() {
            return count;
        }

        @Override
        public int getColumnCount() {
            return 5;
        }

        @Override
        public String getColumnName(int i) {
            String column[] = {"Bill-Id", "Date/Time", "Phone Number", "Payment Type", "Grand Total"};

            return column[i];
        }

        @Override
        public Object getValueAt(int i, int j) {

            bill bi = al.get(i);
            if (j == 0) 
            {
                return bi.billid;
            } else if (j == 1) {
                return bi.datetime;
            } else if (j == 2) {
                return bi.phoneno;
            } else if (j == 3) {
                return bi.paymenttype;
            } else {
                return bi.gtotal;
            }
        }

    }
    
    int count2 = 0;
    
    void showBillDetail(String ans){
        al2.clear();
        StringTokenizer st = new StringTokenizer(ans, ";");
        
        count2 = st.countTokens();
        
        for(int i=0;i<count2;i++){
            String arr = st.nextToken();
            
            StringTokenizer st2 = new StringTokenizer(arr, ",");
            
            int billdetailid = Integer.parseInt(st2.nextToken());
            int billid = Integer.parseInt(st2.nextToken());
            String pname = st2.nextToken();
            int price = Integer.parseInt(st2.nextToken());
            String catname = (st2.nextToken());
            int quantity = Integer.parseInt(st2.nextToken());
            
            al2.add(new billdetail(billdetailid, billid, pname, catname, price, quantity));
            
        }
        tm2.fireTableDataChanged();
    }
    
    public class TableModel2 extends AbstractTableModel{

        @Override
        public int getRowCount() {
            return count2;
        }

        @Override
        public int getColumnCount() {
            return 6;
        }

        @Override
        public String getColumnName(int i) {
            String column[] = {"Bill-Detail id","Bill-Id","pname","price","Category","Quantity"};
            
            return column[i];
        }
        
        @Override
        public Object getValueAt(int i, int j) {
            
            billdetail bi = al2.get(i);
            if(j == 0){
                return bi.billdetailid;
            }else if(j == 1){
                return bi.billid;
            }else if(j == 2){
                return bi.pname;
            }else if(j == 3){
                return bi.price;
            }else if(j == 4){
                return  bi.catname;
            }else{
                return bi.quantity;
            }
        }
        
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BillHistory.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BillHistory.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BillHistory.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BillHistory.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BillHistory().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JLabel jl2;
    // End of variables declaration//GEN-END:variables
}
