public class Cart {
    String pname;
    String catname;
    int price;
    int quantity;
    
    Cart(String pname,String catname, int price, int quantity)
    {
        this.pname = pname;
        this.catname = catname;
        this.price = price;
        this.quantity = quantity;
    }
    
}
