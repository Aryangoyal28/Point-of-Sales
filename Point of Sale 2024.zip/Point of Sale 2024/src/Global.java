public class Global   
{
    public static String email = "";    // to save email while log in
    
    public static int gtotal = 0;      // to save gtotal so it can be used globally
}
